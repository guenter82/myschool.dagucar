from dagucarmodule import DaguCar

class MyDaguCar(DaguCar):
    #faehrt einen links-kreis
    def kreis(self):
		help(__import__)
        for i in range(8):
			self.left()