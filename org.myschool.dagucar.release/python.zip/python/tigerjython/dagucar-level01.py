from dagucarmodule import DaguCar
car = DaguCar(2,1) 
car.forward()
