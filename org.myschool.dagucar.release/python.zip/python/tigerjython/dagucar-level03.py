from dagucarmodule import DaguCar

car = DaguCar(0,3)
