from dagucarmodule import DaguCar

#Neue Befehle definieren
def zumZiel():
    pass
    #Füge hier die DaguCar Befehle aus Aufgabe 1 ein
    
def wende():
    pass
    #Füge hier die DaguCar Befehle aus Aufgabe 2 ein


#Programm
car = DaguCar(0,4)  
#mache das Beispiel fertig
