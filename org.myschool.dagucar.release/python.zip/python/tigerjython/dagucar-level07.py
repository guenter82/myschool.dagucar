from dagucarmodule import DaguCar

car = DaguCar(0,7)
key = car.waitOnNextKey()
while (key != 'q'): ## q ... quit
    print(str(key))
    key = car.waitOnNextKey()

print("Ende")
