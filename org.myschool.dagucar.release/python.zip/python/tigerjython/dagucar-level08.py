from dagucarmodule import DaguCar

car = DaguCar(0,8)
# steuerung mittels w,a,s,d

key = car.waitOnNextKey()
while (key != 'q'):
    if (key == 'w'):
        car.forward()
    elif (key == 's'):
        car.back()
    elif (key == 'a'):
        car.left()
    elif (key == 'd'):
        car.right()
    key = car.waitOnNextKey()

print("Ende")
    
