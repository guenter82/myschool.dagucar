from dagucarmodule import DaguCar

def move(car, key):
    if (key == 'w'):
        car.forward()
    elif (key == 's'):
        car.back()
    elif (key == 'a'):
        car.left()
    elif (key == 'd'):
        car.right()

car = DaguCar(0,0)

datei = open("aufnahme-level3.txt","r")
for zeile in datei:
    key = zeile[0]
    print(key)
    move(car, key)
print("Ende")
