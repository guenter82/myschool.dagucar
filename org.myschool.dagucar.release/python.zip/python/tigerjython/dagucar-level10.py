from dagucarmodule import DaguCar

def move(car, key):
    if (key == 'w'):
        car.forward()
    elif (key == 's'):
        car.back()
    elif (key == 'a'):
        car.left()
    elif (key == 'd'):
        car.right()

car = DaguCar(0,0)

datei = open("aufnahme-level3.txt","w")
key = car.waitOnNextKey()
while key != 'q':
    print(key)
    datei.write(key+"\n") #\n .... neue Zeile
    move(car, key)
    key = car.waitOnNextKey()
datei.close()
datei = open("aufnahme-level3.txt","r")
print("Datei: " + datei.read())
datei.close()
print("Ende")
