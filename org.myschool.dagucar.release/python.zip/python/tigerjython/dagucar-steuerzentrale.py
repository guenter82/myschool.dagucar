from dagucarmodule import DaguCar

#globale Variablen
fileName = "aufnahme.txt"
textWaitOnKey = "Steuerung mit: 'w','a','s','d'\nRecord-Taste: 'r'\n Play-Taste: 'p'\nQuit-Taste: 'q'"
textRecording = "Recording to File!\nSteuerungs-Taste: 'w','a','s','d'\nRecord-Beenden-Taste: 'r'"
textPlaying = "Playing from File ..."

#Funktionen
def move(car, nextkey):
    pass
    #bewege das DaguCar anhand des eingegeben Buchstabens

def playFromFile(car):
    car.setStateText("Replaying ...")
    #Führe alle Steuerbefehle aus der Datei Namen "aufnahme.txt"


def recordToFile(car):
    car.setStateText("Recording ...")
    #Gib dem Benutzer den Text der in der gloablen Variable textRecording steht aus.
    #Speichere alle Tastatureingaben in "aufnahme.txt" und führe alle Bewegungen aus, bis wieder 'r' gedrückt wird.
    #Gib dem Benutzer aus, sobald das Recording beendet wird.

car = DaguCar(0, 3)     #erster Parameter ist die Nummer des DaguCars, zweiter Parameter ist die Simulation-Level

msgDlg(textWaitOnKey)
#warte wiederkehrend auf die nächste Tastatureingabe:
# 'r': führe die Funktion zum Aufnehmen aus
# 'p': führe die Funktion zum Abspielen aus
# 'q': beenden
# andere Taste: führe die Funktion zum Fahren aus
        
car.setStateText("Stopped ...")
