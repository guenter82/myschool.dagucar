from random import randint

sum = 0

stichprobe = 1000

repeat stichprobe:
    w1 = randint(1,6)
    w2 = randint(1,6)
    w3 = randint(1,6)
    
    pasch = w1 == w2 and w2 == w3
   # print w1, " ", w2, " ", w3
    
    versuche = 1
    while not pasch:
        w1 = randint(1,6)
        w2 = randint(1,6)
        w3 = randint(1,6)
        pasch = w1 == w2 and w2 == w3
       # print w1, " ", w2, " ", w3
        versuche = versuche + 1
    
    print w1, " ", w2, " ", w3
    print "Versuche: ", versuche
    sum = sum + versuche
print "Summe: ", sum
print "Simulierte mittlere Versuch: ", (sum/stichprobe)
print "Simulierte Wahrscheinlichkeit: " , 1/(sum/stichprobe)*100, "%"
