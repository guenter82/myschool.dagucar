from dagucarmodule import DaguCar
from org.myschool.dagucar.plugin.remote import DaguCarRemote

fileName = "aufnahme-demo.txt"

textWaitOnKey = "Steuerung mit: 'w','a','s','d'\nRecord-Taste: 'r'\n Play-Taste: 'p'\nQuit-Taste: 'q'"
textRecording = "Recording to File!\nSteuerungs-Taste: 'w','a','s','d'\nRecord-Beenden-Taste: 'r'"
textPlaying = "Playing from File ..."

def directConnection(car)
    remote = car.getRemote()
    byte = 0x1F
    key = ' '
    while key != 'x':
        remote.sendNextByte(byte, 100)
        key = car.waitOnNextKey()
    remote.sendNextByte(0x20, 10) #stopp

def circle(car):
    remote = car.getRemote()
    byteNorthwest = 0x5F
    byteWest = 0x3F
    key = ' '
    while key != 'y':
        remote.sendNextByte(byteNorthwest, 100)
        #remote.sendNextByte(byteWest, 20)
        key = car.waitOnNextKey()
    remote.sendNextByte(0x20, 10) #stopp
    
def move(car, nextkey):
    if nextkey == 'w':
        car.forward()
    if nextkey == 's':
        car.back()
    if nextkey == 'a': 
        car.left()
    if nextkey == 'd':
        car.right()


def playFromFile(car):
    car.setStateText("Replaying ...")
    msgDlg(textPlaying)
    datei = open(fileName, "r")
    for zeile in datei:
        if len(zeile)>0:
            move(car, zeile[0])
    datei.close()


def recordToFile(car):
    car.setStateText("Recording ...")
    msgDlg(textRecording)
    recdatei = open(fileName, "w")
    key = ''
    while key != 'r' and key != 0:
        key=car.waitOnNextKey()
        move(car, key)
        if key !='r':
            recdatei.write(key + "\n")
    recdatei.close();
    msgDlg("Recording ended ...")

car = DaguCar(0, 0)             #erster Parameter ist die Nummer des DaguCars, zweiter Parameter ist die Simulation-Level
msgDlg(textWaitOnKey)
key = ''
while key != 'q' and key != 0:
    car.setStateText("Normal ...")
    key=car.waitOnNextKey()
    print("Taste: " + key)
    if key == 'r':
        recordToFile(car)
    elif key == 'p':
        playFromFile(car)
    elif key == 'x':
        directConnection(car)
    elif key == 'y':
        circle(car)
    else:
        move(car, key)
        
car.setStateText("Stopped ...")
