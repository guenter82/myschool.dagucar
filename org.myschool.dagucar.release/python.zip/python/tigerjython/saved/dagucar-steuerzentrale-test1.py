from dagucarmodule import DaguCar
import time

#globale Variablen
fileName = "aufnahme.txt"
textWaitOnKey = "Steuerung mit: 'w','a','s','d'\nRecord-Taste: 'r'\n Play-Taste: 'p'\nQuit-Taste: 'q'"
textRecording = "Recording to File!\nSteuerungs-Taste: 'w','a','s','d'\nRecord-Beenden-Taste: 'r'"
textPlaying = "Playing from File ..."

#Funktionen
def move(car, nextkey):
    if nextkey == 'w':
        car.forward()
    elif nextkey == 'a':
        car.left()
    elif nextkey == 'd':
        car.right()
    elif nextkey == 's':
        car.back()

def playFromFile(car):
    car.setStateText("Replaying ...")
    msgDlg(textPlaying)
    datei = open("aufnahme.txt", "r")
    i = 0
    for line in datei:
        nextkey=line[0]
        move(car,nextkey)
        i = i + 1
    #Führe alle Steuerbefehle aus der Datei Namen "aufnahme.txt"
    time.sleep(0.2*i )
    msgDlg("Finished replay")

def recordToFile(car):
    car.setStateText("Recording ...")
    msgDlg(textRecording)
    datei = open("aufnahme.txt", "w")
    nextkey = car.waitOnNextKey()
    while nextkey != 'r':
       datei.write(nextkey + "\n")  
       move(car, nextkey)  
       nextkey = car.waitOnNextKey() 
    datei.close()
    msgDlg("Recording finished")
    #Gib dem Benutzer den Text der in der gloablen Variable textRecording steht aus.
    #Speichere alle Tastatureingaben in "aufnahme.txt" und führe alle Bewegungen aus, bis wieder 'r' gedrückt wird.
    #Gib dem Benutzer aus, sobald das Recording beendet wird.

car = DaguCar(0, 3)     #erster Parameter ist die Nummer des DaguCars, zweiter Parameter ist die Simulation-Level

msgDlg(textWaitOnKey)
nextkey = car.waitOnNextKey()
while nextkey != 'q':
    if nextkey == 'r':
        recordToFile(car)
    elif nextkey == 'p':
        playFromFile(car)
    else:
        move(car, nextkey)
    nextkey = car.waitOnNextKey()
    
#warte wiederkehrend auf die nächste Tastatureingabe:
# 'r': führe die Funktion zum Aufnehmen aus
# 'p': führe die Funktion zum Abspielen aus
# 'q': beenden
# andere Taste: führe die Funktion zum Fahren aus
        
car.setStateText("Stopped ...")
