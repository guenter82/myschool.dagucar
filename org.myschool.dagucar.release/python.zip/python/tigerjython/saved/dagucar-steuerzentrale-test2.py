from dagucarmodule import DaguCar

#globale Variablen
fileName = "aufnahme.txt"
textWaitOnKey = "Steuerung mit: 'w','a','s','d'\nRecord-Taste: 'r'\n Play-Taste: 'p'\nQuit-Taste: 'q'"
textRecording = "Recording to File!\nSteuerungs-Taste: 'w','a','s','d'\nRecord-Beenden-Taste: 'r'"
textPlaying = "Playing from File ..."

#Funktionen
def move(car, nextkey):
    if nextkey == 'w':
        car.forward()
    elif nextkey == 's':
        car.back()
    elif nextkey == 'a':
        car.left()
    elif nextkey == 'd':
        car.right()
    #bewege das DaguCar anhand des eingegeben Buchstabens

def playFromFile(car):
    car.setStateText("Replaying ...")
    datei = open("aufnahme.txt", "r")
    msgDlg("Playing file ....")
    for line in datei:
        print(line)
        key = line[0]
        move(car, key)
    datei.close()
    msgDlg("Finished playing file")
    #Führe alle Steuerbefehle aus der Datei Namen "aufnahme.txt"


def recordToFile(car):
    car.setStateText("Recording ...")
    msgDlg(textRecording)
    datei = open("aufnahme.txt", "w")
    key = car.waitOnNextKey()
    while key != 'r':
        datei.write(key + "\n")
        move(car,key)
        key = car.waitOnNextKey()
    datei.close()
    msgDlg("Recording ended")


#Hauptprogramm
car = DaguCar(0, 3)     #erster Parameter ist die Nummer des DaguCars, zweiter Parameter ist die Simulation-Level

msgDlg(textWaitOnKey)
car.setStateText("Running  ...")
key = car.waitOnNextKey()
while key != 'q':
    if key == 'r':
        recordToFile(car)
    elif key == 'p':
        playFromFile(car)
    else :
        move(car, key)
    key = car.waitOnNextKey()
        
car.setStateText("Stopped ...")
