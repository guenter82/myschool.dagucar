from random import randint

def istPasch(w1,w2):
   # print "Wurf", w1, w2
    return w1 == w2 
zaehler = 0 
stichprobe = 10000
repeat stichprobe:
    w1 = randint(1,6)
    w2 = randint(1,6)
    pasch = istPasch(w1,w2)
    if pasch:
        zaehler = zaehler + 1

print "Die Wahrscheinlichkeit eines Pasches ist:", (zaehler / stichprobe)
