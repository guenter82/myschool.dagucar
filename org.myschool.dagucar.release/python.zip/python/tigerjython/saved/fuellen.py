from gturtle import Turtle

t = Turtle()

t.setPenColor("red")
t.setFillColor("green")
t.startPath()

ecken = 5
i = 1
while i <= ecken:
    if i == ecken:
         t.fillPath() #muss füllen bevor zurück geht zum 
    t.forward(300/ecken)
    t.left(360/ecken)
   
    i = i + 1
    
