#from simrobot import *
from nxtrobot import *
from javax.swing import *
import time

nxt1 = 0x1653152D79 

NxtContext.useObstacle("sprites/bg.gif", 250, 250)  
NxtContext.setStartPosition(310, 470)

tMove = 5000
tTurn = 580
tBack = 1300

def createGUI():
    frame = JFrame("Controller")
    p = JPanel()
    p.setPreferredSize(Dimension(200, 40))
    p.add(btnStop)
    p.add(btnRun)
    frame.add(p)
    frame.pack()
    frame.setLocation(600, 40)
    frame.setVisible(True)

def stopCallback(e):
    global isExecuting
    isExecuting = False
    gear.stop()

def runCallback(e):
    global isExecuting
    robot.reset()
    isExecuting = True

def pressCallback(port):
    global startTime
    dt = time.clock() - startTime # time since last hit in s
    print int(1000 * dt) # in ms
    gear.backward(tBack)
    if dt > 2: 
        memory.append(0) # save we turn left
        gear.left(tTurn) 
    
    else:
        memory.pop() # discard node
        memory.append(1) # save we turn right
        gear.right(2 * tTurn)

    print memory
    gear.forward()
    startTime = time.clock()      
        
btnStop = JButton("Stop", actionListener = stopCallback)
btnRun =  JButton("Run", actionListener = runCallback)

#createGUI()

robot = NxtRobot(nxt1)
gear = Gear()
gear.setSpeed(50)
robot.addPart(gear)
ts = TouchSensor(SensorPort.S2, pressed = pressCallback)      
robot.addPart(ts)
startTime = time.clock()
memory = []
gear.forward()

isExecuting = False
while robot.isRunning():
    if isExecuting:
        for k in memory:
            print "Processing node " + str(k), 
            print ": Moving forward",
            gear.forward(tMove)
            if k == 0:
                print "- Turning left"
                gear.left(tTurn)
            else:          
                print "- Turning right"
                gear.right(tTurn)
        
        gear.forward() # must stop manually
        print "All done."
        isExecuting = False
robot.exit()
