from org.myschool.dagucar.plugin import DaguCar

fileName = "aufnahme-demo.txt"

textWaitOnKey = "Steuerung mit: 'w','a','s','d'\nRecord-Taste: 'r'\n Play-Taste: 'p'\nQuit-Taste: 'q'"
textRecording = "Recording to File!\nSteuerungs-Taste: 'w','a','s','d'\nRecord-Beenden-Taste: 'r'"
textPlaying = "Playing from File ..."

def move(car, nextkey):
    if nextkey == 'w':
        car.forward()
    if nextkey == 's':
        car.back()
    if nextkey == 'a': 
        car.left()
    if nextkey == 'd':
        car.right()

def playFromFile(car):
    car.setStateText("Replaying ...")
    msgDlg(textPlaying)
    datei = open(fileName, "r")
    for zeile in datei:
        if len(zeile)>0:
            move(car, zeile[0])
    datei.close()


def recordToFile(car):
    car.setStateText("Recording ...")
    msgDlg(textRecording)
    recdatei = open(fileName, "w")
    key = ''
    while key != 'r' and key != 0:
        key=car.waitOnNextKey()
        move(car, key)
        if key !='r':
            recdatei.write(key + "\n")
    recdatei.close();
    msgDlg("Recording ended ...")

car = DaguCar(1, 2)             #erster Parameter ist die Nummer des DaguCars, zweiter Parameter ist die Simulation-Level

key = ''
while key != 'q' and key != 0:
    car.setStateText("Normal ...")
    key=car.waitOnNextKey()
    print("Taste: " + key)
    if key == 'r':
        recordToFile(car)
    elif key == 'p':
        playFromFile(car)
    else:
        move(car, key)
        
car.setStateText("Stopped ...")
