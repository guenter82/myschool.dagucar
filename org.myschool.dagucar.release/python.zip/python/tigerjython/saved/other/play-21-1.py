
anzahl = inputInt()

i = 0
for x in range(anzahl):
    i = i +1
    print(str(i) + ". Hallo")
