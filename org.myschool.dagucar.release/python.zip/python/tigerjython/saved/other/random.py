import random

pupils = range(1,26)
questions1 = range (1,14)
questions2 = range (1,14)
questions3 = range (1,14)

prev=[0,0,0,0,0,0]
namesData = open("D:/Ablage/python-data/4r-name.txt")
names = []
for z in namesData:
    names.append(z.replace("\r", "").replace("\n","") )
for i in range(25):
    q1 = random.choice(questions1)
    while (q1 in prev):
        q1 = random.choice(questions1)
    q2 = random.choice(questions2)
    while (q1 == q2 or q2 in prev):
         q2 = random.choice(questions2)
    q3 = random.choice(questions3)
    while (q1 == q3 or q2 == q3 or q3 in prev): 
        q3 = random.choice(questions3)
    print(str(q1).rjust(3) + " " + str(q2).rjust(3) + " " + str(q3).rjust(3))
    prev = [prev[3],prev[4],prev[5],q1,q2,q3]
