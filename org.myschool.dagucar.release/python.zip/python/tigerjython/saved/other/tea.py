#from simrobot import *
from nxtrobot import *
from javax.swing import *
import time

NxtContext.useObstacle("sprites/bg2.gif", 250, 250)  
NxtContext.setStartPosition(410, 460)

tTurn = 580
tBack = 1300

def createGUI():
    frame = JFrame("Controller")
    p = JPanel()
    p.setPreferredSize(Dimension(200, 40))
    p.add(btnStop)
    p.add(btnRun)
    frame.add(p)
    frame.pack()
    frame.setLocation(600, 40)
    frame.setVisible(True)

def stopCallback(e):
    global isExecuting
    isExecuting = False
    gear.stop()

def runCallback(e):
    global isExecuting 
    robot.reset()
    isExecuting = True

def pressCallback(port):
    global startTime
    global tMove # long-track time
    dt = time.clock() - startTime # time since last hit in s
    print int(1000 * dt) # in ms
    gear.backward(tBack)
    if dt > 2: # we were on a long track
        tMove = int(dt * 1000) - tBack  # save long-track time
        node = [tMove, 0] 
        memory.append(node) # save long-track time and we turn left
        gear.left(tTurn)  # turning left
    
    else: # we were on a short track
        memory.pop() # discard node
        node = [tMove, 1] 
        memory.append(node) # save long-track time and we turn right
        gear.right(2 * tTurn) # turning right
    
    print memory
    gear.forward()    
    startTime = time.clock()      
        
btnStop = JButton("Stop", actionListener = stopCallback)
btnRun =  JButton("Run", actionListener = runCallback)

createGUI()

robot = NxtRobot()
gear = Gear()
gear.setSpeed(50)
robot.addPart(gear)
ts = TouchSensor(SensorPort.S3, pressed = pressCallback)      
robot.addPart(ts)
tMove = 0
memory = []
gear.forward()
startTime = time.clock()

isExecuting = False
while robot.isRunning():
    if isExecuting:
        for node in memory:
            if not isExecuting:
                break
            print "Processing node " + str(node), 
            tMove = node[0]
            k = node[1]
            print ": Moving forward",
            gear.forward(tMove)
            if k == 0:
                print "- Turning left"
                gear.left(tTurn)

            else:          
                print "- Turning right"
                gear.right(tTurn)

        gear.forward() # must stop manually     
        print "All done." 
        isExecuting = False          
robot.exit()
