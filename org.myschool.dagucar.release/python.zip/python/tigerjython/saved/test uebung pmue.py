from random import randint

repeat 20:
    w1 = randint(1,6)
    print(w1)
