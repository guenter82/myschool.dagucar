from mydagucarmodule import MyDaguCar

car = MyDaguCar(0,0)
car.kreis()
