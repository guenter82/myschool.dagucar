from dagucarmodule import DaguCar

class MyDaguCar(DaguCar):
    #fährt einen links-kreis
    def kreis(self):
        repeat 8:
            self.left()
    
# fährt einen Bogen
def mund():
    car.right()
    car.left()
    car.left()
    car.right()

# Global
car = MyDaguCar(0,0)

repeat 2:
    car.forward()
car.kreis()
mund()
car.kreis()
