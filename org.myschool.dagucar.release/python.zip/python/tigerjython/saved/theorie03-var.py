var = 10
print("var: " + str(var)) 
var = 12
print("var: " + str(var))

i = var + 5
print ("i: " + str(i))

#Algorithmus zum Zählen
i = i + 1
print ("i: " + str(i))


a = 1000
b = 5
#sortieren
if a > b: 
    #Algorithmus zum Tauschen von Werten in Speicherzellen
    help = a
    a = b
    b = help

print("Kleinere Zahl:" + str(a))
print("Größere Zahl:" + str(b))

i = 1
anz = inputInt()
repeat anz:
    print (str(i) + ". Hallo")
    i += 1
