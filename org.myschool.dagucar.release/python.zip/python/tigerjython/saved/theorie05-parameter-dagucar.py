from org.myschool.dagucar.plugin import DaguCar

def forward(car, count):
    repeat count:
        car.forward()
def left(car, count):
    repeat count:
        car.left()

mycar = DaguCar(0,0)
anz = 5
forward(mycar, anz)
anz = 4
left(mycar, anz)
anz = 3
forward(mycar, anz)
