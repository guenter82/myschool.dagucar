from gturtle import Turtle

t = Turtle("sprites/spider.png")

a = 20
while (a<100):
    t.forward(a)
    t.right(90)
    a = a + 2 
