"""       
i = 0
repeat 40:    
    if i < 20:
        print("Kleiner 20: " + str(i))
    else :
        print("Gleich 20 oder Größer: " + str(i))
    i = i + 1
"""    
from org.myschool.dagucar.plugin import DaguCar
car = DaguCar(0,0)
repeat 5:
    eingabe = inputString("Gib einen Buchstaben ein")
    if eingabe != 'w':
        car.back()
    else :
        car.forward()
 
