from gturtle import Turtle
from math import pi

t=Turtle()
i=1
vieleck=3

maxecken= inputInt("Ecken:")
#anzahl= inputInt("Anzahl:")
radius=radius
umfang = 2*200*pi
t.right(90)
t.move(radius)
t.left(90)
while vieleck <= maxecken :
    ecken = vieleck
    while i<= ecken:
        t.forward(umfang/ecken)
        t.left(360/ecken)  
        i=i+1    
    #t.right(360/anzahl)
    i=1
    vieleck = vieleck + 1
