from gturtle import Turtle

t=Turtle()
i=3

while i>2:
    repeat i:
        t.forward(900/i)
        t.left(360/i)
    i=i+1
