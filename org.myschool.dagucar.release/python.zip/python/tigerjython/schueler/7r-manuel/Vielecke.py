from gturtle import Turtle

t=Turtle()
i=1

ecken= inputInt("Ecken:")
  
repeat ecken:
    while i<= ecken:
        t.forward(800/ecken)
        t.left(360/ecken)  
        i=i+1    
    t.right(360/ecken)
    i=1
