from gturtle import Turtle
from dagucarmodule import DaguCar

t = Turtle()
t.forward(141)
t.left(135)
t.forward(100)
t.left(90)
t.forward(100)

car = DaguCar(0,0)
car.forward()
car.left()
car.forward()
car.left()
car.forward()
