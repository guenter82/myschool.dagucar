from gturtle import Turtle

def vieleck(t, ecken):
    i = 0
    while i < ecken :
        i = i + 1
        t.forward(50)
        t.left(360/ecken)    


t = Turtle()


#Wiederhole bis key == "q"
nochmal = True 
while nochmal:
    ecken = inputInt("Ecken:")
    vieleck(t, ecken)
    t.right(30)
    nochmal = askYesNo("Nochmal")  
