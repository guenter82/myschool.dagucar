from org.myschool.dagucar.plugin import DaguCar

car = DaguCar(0,4)
