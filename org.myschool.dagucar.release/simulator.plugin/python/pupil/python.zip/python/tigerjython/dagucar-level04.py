from org.myschool.dagucar.plugin import DaguCar

def goAroundObstacle():
    pass
    #Füge hier die DaguCar Befehle aus Aufgabe 1 ein
    
def turnAround():
    pass
    #Füge hier die DaguCar Befehle aus Aufgabe 2 ein

car = DaguCar(0,4)  
#mache das Beispiel fertig
