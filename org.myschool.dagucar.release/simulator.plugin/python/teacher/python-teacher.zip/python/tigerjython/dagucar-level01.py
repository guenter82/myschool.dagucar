from org.myschool.dagucar.plugin import DaguCar

car = DaguCar(0,1) 

repeat 6:               
    car.forward()       
car.left()
car.left()

car.right()
car.right()
car.back()
car.back()
car.right()
car.right()

#mache das Beispiel fertig
