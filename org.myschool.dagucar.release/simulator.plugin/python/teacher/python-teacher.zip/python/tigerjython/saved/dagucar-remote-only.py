from org.myschool.dagucar.plugin.remote import DaguCarRemote

remote = DaguCarRemote(3)
remote.sendNextByte(0x1F, 1000); #Nach vorne mit maximaler Geschwindigkeit für 1000 ms
remote.sendNextByte(0x20, 1000); #Stopp
