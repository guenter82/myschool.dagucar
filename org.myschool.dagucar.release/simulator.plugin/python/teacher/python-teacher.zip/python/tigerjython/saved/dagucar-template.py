from org.myschool.dagucar.plugin import DaguCar

dagu = DaguCar(0)
