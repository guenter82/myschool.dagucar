from org.myschool.dagucar.plugin import DaguCar

def nextKreis():
    car.forward()
    kreis()
    
def kreis():
    repeat 8:
        car.left()

# Global
car = DaguCar(0,0)
print(car)

repeat 2:
    car.forward()

repeat 8:
    nextKreis()
