from org.myschool.dagucar.plugin import DaguCar
#Funktionen
def halbkreis():
    repeat 4:
        print(car.left())
def kreis():
    halbkreis()
    halbkreis()

#Hauptprogramm
car = DaguCar(0,0)

repeat 3:
    car.forward()
repeat 2:
    kreis()
    car.forward()
halbkreis()
