from gturtle import Turtle
from math import sqrt   #Funktion zum Wurzelziehen

def quadrat(turtle, laenge):
    repeat 4:
        turtle.forward(laenge)
        turtle.left(90)

t = Turtle()        #Turtle Object, startet nach Norden sehend

a1 = 100            #Seitenlänge äußeres Quadrat
a2 = 50*sqrt(2)     #Seitenlänge inneres Quadrat

quadrat(t, a1)
t.forward(50)
t.left(45)
quadrat(t, a2)
